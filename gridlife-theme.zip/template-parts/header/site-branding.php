<?php
/**
 * Displays header site branding
 *
 * @package WordPress
 * @subpackage Autumn
 * @since 1.0.0
 */

echo gridlife_theme_logo('site__branding img-fluid', $schema=array('itemtype'=>'http://schema.org/NewsMediaOrganization'));
