# gridlife
Custom theme in wordpress for creating blog and similar sites
